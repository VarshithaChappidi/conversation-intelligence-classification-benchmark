# Model card: Customer-support intent classification

## Intended use

This project compares text-classification approaches for routing short customer-support messages to one of the BANKING77 intents. It is an educational benchmark and a starting point for offline evaluation, not a production banking system.

## Models

- Baseline: word/character-independent TF-IDF word n-grams (1–2) with logistic regression.
- Optional comparison: fine-tuned DistilBERT sequence classifier.

The code reports accuracy, macro-F1, weighted-F1, per-intent metrics, and misclassified examples. The test split is used for final evaluation only. The transformer checkpoint is selected using a validation split carved from the official training data.

## Data

BANKING77 contains English banking customer-service queries labelled with 77 intents. The upstream dataset card reports 10,003 training examples and 3,080 test examples. See the dataset's CC BY 4.0 license and attribution details in `README.md`.

## Limitations and risks

- The dataset represents a single English-language banking domain and may not represent a particular institution, customer population, channel, or current product terminology.
- Several intent labels are semantically similar; a correct top-level intent does not mean a response is factually correct or that a request has been resolved.
- Predicted probabilities are not necessarily calibrated confidence scores. Do not treat them as guarantees.
- The benchmark does not include out-of-domain detection, human handoff, fairness testing, or personal-data safeguards for arbitrary user-supplied text.
- Do not route real financial actions or deny service solely on the basis of this model. Add human oversight, domain validation, privacy controls, and monitoring before any real-world use.

## Evaluation status

No performance number is committed in this repository in advance. Run the documented commands to generate metrics on the official test split. Record actual outputs and environment details before making model-quality claims.
