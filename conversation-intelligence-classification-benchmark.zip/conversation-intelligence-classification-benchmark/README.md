# Customer Support Intent Classification Benchmark

**Compare a classical NLP baseline with a transformer model for fine-grained customer-support routing.**

This project is designed as a reproducible portfolio benchmark: the data source is explicit, test data remains separate from transformer model selection, metrics are standardized, common errors are saved for inspection, and lightweight tests run in GitHub Actions.

> **Status:** Initial implementation. No benchmark scores are claimed until the training commands are run in your environment.

## What it does

- Loads and validates the official BANKING77 train/test CSVs and caches them under `data/raw/`.
- Trains a TF-IDF word n-gram + logistic-regression baseline.
- Optionally fine-tunes DistilBERT using a validation split from training data.
- Reports accuracy, macro-F1, weighted-F1, per-intent performance, and misclassified examples.
- Compares saved baseline and transformer metrics in one console table.
- Saves a model artifact and supports top-k intent predictions.
- Includes a small Streamlit interface and unit tests for data validation, metrics, and inference helpers.

## Dataset

[BANKING77 on Hugging Face](https://huggingface.co/datasets/PolyAI/banking77) is a single-domain intent-classification dataset of **13,083 English banking customer-service queries across 77 intents**: 10,003 train examples and 3,080 test examples. The original CSV source is maintained by [PolyAI-LDN](https://github.com/PolyAI-LDN/task-specific-datasets). The dataset card identifies the data license as **Creative Commons Attribution 4.0 International (CC BY 4.0)**. The dataset is downloaded on demand and is not redistributed in this repository.

Dataset paper: Iñigo Casanueva et al., [*Efficient Intent Detection with Dual Sentence Encoders* (2020)](https://arxiv.org/abs/2003.04807). Dataset use should follow its license and attribution requirements; that license is separate from the MIT license for this project's code.

## Quick start

Python 3.10+ is required. These commands work from the repository root.

```bash
python -m venv .venv
# Windows PowerShell: .venv\Scripts\Activate.ps1
# macOS/Linux: source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e ".[dev]"
```

### 1. Run tests

```bash
python -m pytest -q
```

Tests use small in-memory examples and do not download the dataset.

### 2. Train and evaluate the baseline

```bash
python -m intent_benchmark.train_baseline
```

On the first run, the official train/test CSV files are downloaded to `data/raw/`. Outputs are written to `artifacts/baseline/`:

| File | Contents |
|---|---|
| `model.joblib` | Trained scikit-learn pipeline and metadata |
| `metrics.json` | Accuracy, macro-F1, weighted-F1, split sizes, and label count |
| `per_class_report.csv` | Precision, recall, F1, and support for each intent |
| `predictions.csv` | Test text, true label, predicted label, confidence, and correctness |
| `misclassifications.csv` | Incorrect test predictions sorted by model confidence |
| `model_card.json` | Model and evaluation metadata |

To use a custom cache/output path or refresh the local data cache:

```bash
python -m intent_benchmark.train_baseline --data-dir data/raw --output-dir artifacts/baseline
python -m intent_benchmark.train_baseline --force-download
```

### 3. Try a prediction

After baseline training:

```bash
python -m intent_benchmark.predict --text "My bank transfer has not arrived" --top-k 5
```

### 4. Launch the interactive demo

```bash
python -m pip install -e ".[demo]"
streamlit run app.py
```

Train the baseline before launching the app. The demo runs locally and is not deployed publicly by this repository.

### 5. Optional transformer comparison

The transformer path needs PyTorch and Hugging Face libraries, downloads model weights, and is more compute-intensive than the baseline.

```bash
python -m pip install -e ".[transformer]"
python -m intent_benchmark.train_transformer --epochs 3
```

By default, it fine-tunes `distilbert/distilbert-base-uncased`. It creates a stratified validation split from the official training data (seed 42), selects the best checkpoint by validation macro-F1, then evaluates once on the official test split. Output goes to `artifacts/transformer/`.

After both runs finish, compare results with:

```bash
python -m intent_benchmark.compare --baseline artifacts/baseline/metrics.json --transformer artifacts/transformer/metrics.json
```

## Evaluation methodology

- **Accuracy:** overall fraction of correct predictions.
- **Macro-F1:** unweighted mean of per-intent F1 scores; useful when all intents should matter equally.
- **Weighted-F1:** per-intent F1 weighted by class support.
- **Error analysis:** incorrect test examples and per-intent precision/recall/F1 are saved for review.

The classical baseline uses the official train split for fitting and the official test split for final reporting. Transformer model selection uses a held-out validation subset of training data; the official test split is not used for checkpoint selection. Keep the test split out of any parameter or threshold tuning.

Do not compare runs as a fair benchmark unless they use the same dataset version and test split. Log package versions and hardware when reporting results. Do not write performance claims into a resume until actual runs have completed and their metrics are preserved.

## Repository structure

```text
.
├── .github/workflows/ci.yml
├── app.py
├── MODEL_CARD.md
├── pyproject.toml
├── src/intent_benchmark/
│   ├── compare.py
│   ├── data.py
│   ├── metrics.py
│   ├── predict.py
│   ├── train_baseline.py
│   └── train_transformer.py
└── tests/
    ├── test_data.py
    ├── test_metrics.py
    └── test_predict.py
```

## Limitations and responsible use

This is a research/portfolio benchmark on a single English-language banking domain. Intents can overlap semantically; model confidence is not guaranteed to be calibrated. The project does not implement out-of-domain detection, transaction execution, production monitoring, fairness auditing, or personally identifiable information handling. See [MODEL_CARD.md](MODEL_CARD.md). Do not use predictions alone to approve, deny, or execute financial actions.

## License

The implementation code is licensed under MIT. BANKING77 is a separately licensed dataset (CC BY 4.0); refer to its [dataset card](https://huggingface.co/datasets/PolyAI/banking77) and [source repository](https://github.com/PolyAI-LDN/task-specific-datasets) for the original terms and attribution.
