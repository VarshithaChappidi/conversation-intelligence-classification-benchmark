"""Small Streamlit interface for a locally trained baseline model."""

from pathlib import Path

import joblib
import streamlit as st

from intent_benchmark.predict import predict_top_k

st.set_page_config(page_title="Intent Classification Lab", page_icon="🧭", layout="centered")
st.title("Customer Support Intent Classification")
st.caption("A reproducible BANKING77 benchmark · TF-IDF + Logistic Regression")

model_path = Path("artifacts/baseline/model.joblib")
if not model_path.exists():
    st.warning("No trained model found yet. Run the baseline training command from the README first.")
    st.code("python -m intent_benchmark.train_baseline", language="bash")
    st.stop()

bundle = joblib.load(model_path)
text = st.text_area(
    "Customer message",
    placeholder="Example: I transferred money yesterday, but it has not arrived.",
    height=120,
)
top_k = st.slider("Number of candidate intents", min_value=1, max_value=10, value=5)

if st.button("Classify message", type="primary", disabled=not text.strip()):
    results = predict_top_k(text, bundle, k=top_k)
    st.subheader("Predicted intent")
    st.metric(results[0]["intent"], f'{results[0]["confidence"]:.1%} model confidence')
    st.caption("Scores are model probabilities, not calibrated guarantees.")
    st.subheader("Other candidates")
    st.dataframe(
        [{"Intent": row["intent"], "Model confidence": row["confidence"]} for row in results],
        hide_index=True,
        use_container_width=True,
    )
