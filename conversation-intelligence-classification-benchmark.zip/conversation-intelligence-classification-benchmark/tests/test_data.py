import pandas as pd
import pytest

from intent_benchmark.data import validate_frame


def test_validate_frame_trims_text_and_intent_labels():
    frame = pd.DataFrame({"text": ["  Where is my card?  "], "category": [" card_arrival "]})
    cleaned = validate_frame(frame, "unit-test")
    assert cleaned.loc[0, "text"] == "Where is my card?"
    assert cleaned.loc[0, "category"] == "card_arrival"


def test_validate_frame_rejects_missing_columns():
    with pytest.raises(ValueError, match="missing required columns"):
        validate_frame(pd.DataFrame({"text": ["hello"]}), "unit-test")


def test_validate_frame_rejects_null_values():
    frame = pd.DataFrame({"text": [None], "category": ["card_arrival"]})
    with pytest.raises(ValueError, match="null"):
        validate_frame(frame, "unit-test")


def test_validate_frame_rejects_blank_text():
    frame = pd.DataFrame({"text": ["   "], "category": ["card_arrival"]})
    with pytest.raises(ValueError, match="blank text"):
        validate_frame(frame, "unit-test")
