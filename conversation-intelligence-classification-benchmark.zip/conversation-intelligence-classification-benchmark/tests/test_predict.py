import numpy as np
import pytest

from intent_benchmark.predict import predict_top_k


class FakeModel:
    def predict_proba(self, texts):
        assert texts == ["where is my card?"]
        return np.asarray([[0.2, 0.7, 0.1]])


class FakeClassifier:
    classes_ = np.asarray(["card_arrival", "card_delivery_estimate", "lost_or_stolen_card"])


class FakePipeline:
    named_steps = {"classifier": FakeClassifier()}

    def predict_proba(self, texts):
        return FakeModel().predict_proba(texts)


def test_predict_top_k_sorts_scores_descending():
    results = predict_top_k("where is my card?", {"pipeline": FakePipeline()}, k=2)
    assert results[0]["intent"] == "card_delivery_estimate"
    assert results[0]["confidence"] == 0.7
    assert len(results) == 2


def test_predict_top_k_rejects_blank_text():
    with pytest.raises(ValueError, match="non-empty"):
        predict_top_k("   ", {"pipeline": FakePipeline()})


def test_predict_top_k_rejects_invalid_k():
    with pytest.raises(ValueError, match="at least 1"):
        predict_top_k("hello", {"pipeline": FakePipeline()}, k=0)
