import pytest

from intent_benchmark.metrics import classification_metrics


def test_classification_metrics_returns_accuracy_and_f1():
    result = classification_metrics(
        ["card_arrival", "cash_withdrawal", "card_arrival"],
        ["card_arrival", "cash_withdrawal", "cash_withdrawal"],
    )
    assert result["n_examples"] == 3
    assert result["accuracy"] == pytest.approx(2 / 3, abs=1e-5)
    assert "macro_f1" in result
    assert "weighted_f1" in result


def test_classification_metrics_rejects_empty_data():
    with pytest.raises(ValueError, match="empty"):
        classification_metrics([], [])


def test_classification_metrics_rejects_length_mismatch():
    with pytest.raises(ValueError, match="same length"):
        classification_metrics(["card_arrival"], [])
