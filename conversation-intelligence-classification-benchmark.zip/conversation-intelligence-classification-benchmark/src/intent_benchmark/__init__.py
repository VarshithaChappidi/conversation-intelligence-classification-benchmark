"""Customer-support intent classification benchmark."""

__version__ = "0.1.0"
