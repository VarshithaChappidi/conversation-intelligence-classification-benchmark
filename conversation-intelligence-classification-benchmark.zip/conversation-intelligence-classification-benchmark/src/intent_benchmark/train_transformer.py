"""Optional DistilBERT fine-tuning comparison for BANKING77."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from datasets import Dataset
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, classification_report
from transformers import (
    AutoModelForSequenceClassification,
    AutoTokenizer,
    DataCollatorWithPadding,
    Trainer,
    TrainingArguments,
)

from intent_benchmark.data import load_splits


def run(data_dir: str | Path, output_dir: str | Path, model_name: str, epochs: int) -> dict:
    train_df, test_df = load_splits(data_dir)
    labels = sorted(train_df["category"].unique().tolist())
    label2id = {label: index for index, label in enumerate(labels)}
    id2label = {index: label for label, index in label2id.items()}

    fit_df, validation_df = train_test_split(
        train_df, test_size=0.15, random_state=42, stratify=train_df["category"]
    )

    def to_dataset(frame: pd.DataFrame) -> Dataset:
        converted = frame[["text", "category"]].copy()
        converted["labels"] = converted.pop("category").map(label2id).astype(int)
        return Dataset.from_pandas(converted, preserve_index=False)

    tokenizer = AutoTokenizer.from_pretrained(model_name)

    def tokenize(batch: dict) -> dict:
        return tokenizer(batch["text"], truncation=True, max_length=128)

    fit_data = to_dataset(fit_df).map(tokenize, batched=True, remove_columns=["text"])
    validation_data = to_dataset(validation_df).map(tokenize, batched=True, remove_columns=["text"])
    test_data = to_dataset(test_df).map(tokenize, batched=True, remove_columns=["text"])

    model = AutoModelForSequenceClassification.from_pretrained(
        model_name, num_labels=len(labels), label2id=label2id, id2label=id2label
    )

    def compute_metrics(eval_prediction) -> dict[str, float]:
        logits, true_ids = eval_prediction
        pred_ids = np.argmax(logits, axis=-1)
        return {
            "accuracy": float(accuracy_score(true_ids, pred_ids)),
            "macro_f1": float(f1_score(true_ids, pred_ids, average="macro", zero_division=0)),
            "weighted_f1": float(f1_score(true_ids, pred_ids, average="weighted", zero_division=0)),
        }

    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    arguments = TrainingArguments(
        output_dir=str(out / "checkpoints"),
        eval_strategy="epoch",
        save_strategy="epoch",
        load_best_model_at_end=True,
        metric_for_best_model="macro_f1",
        greater_is_better=True,
        learning_rate=2e-5,
        per_device_train_batch_size=16,
        per_device_eval_batch_size=32,
        num_train_epochs=epochs,
        weight_decay=0.01,
        logging_steps=50,
        save_total_limit=2,
        seed=42,
        report_to="none",
    )
    trainer = Trainer(
        model=model,
        args=arguments,
        train_dataset=fit_data,
        eval_dataset=validation_data,
        processing_class=tokenizer,
        data_collator=DataCollatorWithPadding(tokenizer=tokenizer),
        compute_metrics=compute_metrics,
    )
    trainer.train()
    trainer.save_model(str(out / "model"))
    tokenizer.save_pretrained(str(out / "model"))

    test_output = trainer.predict(test_data)
    pred_ids = np.argmax(test_output.predictions, axis=-1)
    true_ids = np.asarray(test_data["labels"])
    predictions = [id2label[int(index)] for index in pred_ids]
    actuals = [id2label[int(index)] for index in true_ids]
    metrics = {
        "model": model_name,
        "dataset": "BANKING77",
        "n_train_total": int(len(train_df)),
        "n_train_fit": int(len(fit_df)),
        "n_validation": int(len(validation_df)),
        "n_test": int(len(test_df)),
        "n_intents": len(labels),
        **compute_metrics((test_output.predictions, true_ids)),
    }
    (out / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    pd.DataFrame(
        {
            "text": test_df["text"].reset_index(drop=True),
            "actual_intent": actuals,
            "predicted_intent": predictions,
        }
    ).to_csv(out / "predictions.csv", index=False)
    report = classification_report(
        actuals, predictions, labels=labels, output_dict=True, zero_division=0
    )
    report_rows = {name: values for name, values in report.items() if isinstance(values, dict)}
    pd.DataFrame.from_dict(report_rows, orient="index").to_csv(
        out / "per_class_report.csv", index_label="intent"
    )
    print(json.dumps(metrics, indent=2))
    return metrics


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", default="data/raw")
    parser.add_argument("--output-dir", default="artifacts/transformer")
    parser.add_argument("--model-name", default="distilbert/distilbert-base-uncased")
    parser.add_argument("--epochs", type=int, default=3)
    args = parser.parse_args()
    if args.epochs < 1:
        raise SystemExit("--epochs must be at least 1")
    run(args.data_dir, args.output_dir, args.model_name, args.epochs)


if __name__ == "__main__":
    main()
