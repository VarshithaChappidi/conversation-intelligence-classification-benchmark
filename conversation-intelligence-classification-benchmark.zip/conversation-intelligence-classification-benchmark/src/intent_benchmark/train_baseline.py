"""Train and evaluate a TF-IDF + logistic-regression intent classifier."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
from sklearn.pipeline import Pipeline

from intent_benchmark.data import load_splits
from intent_benchmark.metrics import classification_metrics


def build_model() -> Pipeline:
    """Build a sparse n-gram baseline that is inexpensive to reproduce."""
    return Pipeline(
        steps=[
            (
                "tfidf",
                TfidfVectorizer(
                    ngram_range=(1, 2),
                    min_df=2,
                    max_features=250_000,
                    strip_accents="unicode",
                    sublinear_tf=True,
                ),
            ),
            ("classifier", LogisticRegression(C=4.0, max_iter=1500, solver="lbfgs")),
        ]
    )


def run(data_dir: str | Path, output_dir: str | Path, force_download: bool = False) -> dict:
    train_df, test_df = load_splits(data_dir, force_download=force_download)
    model = build_model()
    model.fit(train_df["text"], train_df["category"])

    predictions = model.predict(test_df["text"])
    probabilities = model.predict_proba(test_df["text"])
    confidence = probabilities.max(axis=1)
    classes = list(model.named_steps["classifier"].classes_)

    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    metrics = classification_metrics(test_df["category"].tolist(), predictions.tolist())
    metrics.update(
        {
            "model": "tfidf_logistic_regression",
            "dataset": "BANKING77",
            "n_train": int(len(train_df)),
            "n_test": int(len(test_df)),
            "n_intents": len(classes),
        }
    )
    (out / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")

    report = classification_report(
        test_df["category"], predictions, labels=classes, output_dict=True, zero_division=0
    )
    report_rows = {name: values for name, values in report.items() if isinstance(values, dict)}
    pd.DataFrame.from_dict(report_rows, orient="index").to_csv(
        out / "per_class_report.csv", index_label="intent"
    )

    prediction_frame = pd.DataFrame(
        {
            "text": test_df["text"],
            "actual_intent": test_df["category"],
            "predicted_intent": predictions,
            "confidence": confidence,
        }
    )
    prediction_frame["correct"] = prediction_frame["actual_intent"].eq(
        prediction_frame["predicted_intent"]
    )
    prediction_frame.to_csv(out / "predictions.csv", index=False)
    (
        prediction_frame.loc[~prediction_frame["correct"]]
        .sort_values("confidence", ascending=False)
        .to_csv(out / "misclassifications.csv", index=False)
    )

    bundle = {
        "pipeline": model,
        "labels": classes,
        "metadata": {
            "model_name": "TF-IDF + Logistic Regression",
            "dataset": "BANKING77",
            "training_examples": int(len(train_df)),
            "test_examples": int(len(test_df)),
            "metrics": metrics,
        },
    }
    joblib.dump(bundle, out / "model.joblib")
    (out / "model_card.json").write_text(json.dumps(bundle["metadata"], indent=2), encoding="utf-8")

    print(json.dumps(metrics, indent=2))
    print(f"\nSaved model and evaluation outputs to: {out.resolve()}")
    return metrics


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", default="data/raw", help="Directory for cached dataset CSVs")
    parser.add_argument("--output-dir", default="artifacts/baseline", help="Output model directory")
    parser.add_argument("--force-download", action="store_true", help="Refresh cached dataset files")
    args = parser.parse_args()
    run(args.data_dir, args.output_dir, force_download=args.force_download)


if __name__ == "__main__":
    main()
