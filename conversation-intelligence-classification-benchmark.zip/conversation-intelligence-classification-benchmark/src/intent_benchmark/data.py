"""Download and validate the public BANKING77 train/test CSV files."""

from __future__ import annotations

from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen

import pandas as pd

DATA_URLS = {
    "train": "https://raw.githubusercontent.com/PolyAI-LDN/task-specific-datasets/master/banking_data/train.csv",
    "test": "https://raw.githubusercontent.com/PolyAI-LDN/task-specific-datasets/master/banking_data/test.csv",
}
REQUIRED_COLUMNS = {"text", "category"}


def validate_frame(frame: pd.DataFrame, split_name: str = "dataset") -> pd.DataFrame:
    """Validate and standardize a split without silently dropping questionable rows."""
    missing = REQUIRED_COLUMNS.difference(frame.columns)
    if missing:
        raise ValueError(f"{split_name}: missing required columns: {', '.join(sorted(missing))}")
    if frame.empty:
        raise ValueError(f"{split_name}: dataset split is empty")

    clean = frame[["text", "category"]].copy()
    if clean.isna().any().any():
        raise ValueError(f"{split_name}: null text or category values found")

    clean["text"] = clean["text"].astype(str).str.strip()
    clean["category"] = clean["category"].astype(str).str.strip()
    if clean["text"].eq("").any():
        raise ValueError(f"{split_name}: blank text values found")
    if clean["category"].eq("").any():
        raise ValueError(f"{split_name}: blank category values found")
    return clean.reset_index(drop=True)


def _download_if_missing(url: str, destination: Path, force_download: bool) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists() and not force_download:
        return

    try:
        with urlopen(url, timeout=30) as response:
            if response.status != 200:
                raise RuntimeError(f"Dataset download returned HTTP {response.status}: {url}")
            content = response.read()
    except (URLError, TimeoutError, OSError) as exc:
        raise RuntimeError(
            f"Could not download the dataset from {url}. Check your network connection, "
            "or place the official CSV at the expected path and retry."
        ) from exc

    destination.write_bytes(content)


def load_splits(
    data_dir: str | Path = "data/raw", force_download: bool = False
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return validated train and test dataframes; files are cached locally."""
    root = Path(data_dir)
    frames: dict[str, pd.DataFrame] = {}
    for split_name, url in DATA_URLS.items():
        path = root / f"{split_name}.csv"
        _download_if_missing(url, path, force_download)
        frames[split_name] = validate_frame(pd.read_csv(path), split_name)

    train_labels = set(frames["train"]["category"])
    test_labels = set(frames["test"]["category"])
    if train_labels != test_labels:
        missing_from_test = sorted(train_labels - test_labels)
        missing_from_train = sorted(test_labels - train_labels)
        raise ValueError(
            "Train/test label sets do not match. "
            f"Missing from test: {missing_from_test}; missing from train: {missing_from_train}"
        )
    return frames["train"], frames["test"]
