"""Predict a top-k intent list using a previously trained baseline model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib


def predict_top_k(text: str, bundle: dict, k: int = 5) -> list[dict[str, str | float]]:
    if not isinstance(text, str) or not text.strip():
        raise ValueError("text must be a non-empty string")
    if k < 1:
        raise ValueError("k must be at least 1")

    model = bundle["pipeline"]
    probabilities = model.predict_proba([text.strip()])[0]
    classes = list(model.named_steps["classifier"].classes_)
    top_indices = sorted(range(len(probabilities)), key=probabilities.__getitem__, reverse=True)[:k]
    return [
        {"intent": str(classes[index]), "confidence": round(float(probabilities[index]), 6)}
        for index in top_indices
    ]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--text", required=True, help="Customer-support message to classify")
    parser.add_argument("--model-dir", default="artifacts/baseline")
    parser.add_argument("--top-k", type=int, default=5)
    args = parser.parse_args()

    model_path = Path(args.model_dir) / "model.joblib"
    if not model_path.exists():
        raise SystemExit(f"Model not found at {model_path}. Train the baseline first.")
    bundle = joblib.load(model_path)
    print(json.dumps(predict_top_k(args.text, bundle, k=args.top_k), indent=2))


if __name__ == "__main__":
    main()
