"""Compare saved baseline and transformer metric JSON files."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

METRICS = ("accuracy", "macro_f1", "weighted_f1")


def read_metrics(path: str | Path) -> dict:
    source = Path(path)
    if not source.exists():
        raise FileNotFoundError(f"Metrics file not found: {source}. Run that model first.")
    data = json.loads(source.read_text(encoding="utf-8"))
    missing = [key for key in METRICS if key not in data]
    if missing:
        raise ValueError(f"{source} is missing required metric fields: {missing}")
    return data


def compare(baseline_path: str | Path, transformer_path: str | Path) -> str:
    baseline = read_metrics(baseline_path)
    transformer = read_metrics(transformer_path)
    if baseline.get("dataset") != transformer.get("dataset"):
        raise ValueError("Models were not evaluated on the same named dataset")
    if baseline.get("n_test") != transformer.get("n_test"):
        raise ValueError("Models report different test-set sizes; investigate before comparing")

    lines = [
        "Metric             Baseline       Transformer     Delta (transformer - baseline)",
        "-" * 82,
    ]
    for metric in METRICS:
        left = float(baseline[metric])
        right = float(transformer[metric])
        lines.append(f"{metric:<18} {left:>8.4f}         {right:>8.4f}          {right - left:+.4f}")
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", default="artifacts/baseline/metrics.json")
    parser.add_argument("--transformer", default="artifacts/transformer/metrics.json")
    args = parser.parse_args()
    print(compare(args.baseline, args.transformer))


if __name__ == "__main__":
    main()
