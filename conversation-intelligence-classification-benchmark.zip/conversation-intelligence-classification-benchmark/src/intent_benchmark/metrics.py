"""Metrics shared by classical and transformer model evaluation."""

from __future__ import annotations

from collections.abc import Sequence

from sklearn.metrics import accuracy_score, f1_score


def classification_metrics(
    y_true: Sequence[str], y_pred: Sequence[str]
) -> dict[str, float | int]:
    """Compute comparable classification metrics with explicit macro averaging."""
    if len(y_true) == 0:
        raise ValueError("Cannot evaluate an empty set of examples")
    if len(y_true) != len(y_pred):
        raise ValueError("y_true and y_pred must have the same length")

    return {
        "n_examples": int(len(y_true)),
        "accuracy": round(float(accuracy_score(y_true, y_pred)), 6),
        "macro_f1": round(float(f1_score(y_true, y_pred, average="macro", zero_division=0)), 6),
        "weighted_f1": round(float(f1_score(y_true, y_pred, average="weighted", zero_division=0)), 6),
    }
